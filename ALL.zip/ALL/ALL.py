import numpy as np
import random
import time
import pygame as pg
import sys

pg.init()

# REACTION GLOBALS
WAIT = (220, 100, 100)
CLICK = (100, 220, 100)
BACKGROUND = (150, 150, 150)
FONT = pg.font.SysFont('timesnewroman.ttf', 72)
TEXT = (20, 20, 20)

# SEQUENCE GLOBALS
MAPSIZE = 3
SEQSPEED = 0.4
SCREENSIZE = 700

SHOWN = (140, 140, 220)
CLICKED = (220, 140, 140)
EMPTY = (170,170,170)
BACKGROUND = (255,255,255)
FONT = pg.font.SysFont("timesnewroman.ttf", 72)
TEXT = (20, 20, 20)

# VISUAL GLOBALS
VISSPEED = 0.5
SCREENSIZE = 700
SHLICKED = (170, 140, 170)

# CHIMP GLOBALS
CHIMPSIZE = 50 # WARNING: IF SIZE IS TOO BIG, THE GAME WILL START TO LAG AND EVENTUALLY CRASH DUE TO THE NUMBER OF BOXES NOT FITTING ON SCREEN, KEEP THE SIZE/SCREENSIZE RATIO BELOW 1/10
SCREENSIZE = 700 # ALSO IF THE SCREEN IS TOO SMALL, REMEMBER, 1/10 RATIO

# AIM GLOBALS
AIMSIZE = 100
HEIGHT = 700
WIDTH = 1000
BOXCOUNT = 15

# NUMBERS GLOBALS
WRITE = (220, 140, 140)
WIN = (40,200,40)
LOSS = (200,40,40)

# VERBAL GLOBALS
SCREENSIZE = 700
BUTTONSIZE = 100

SHOWNBUTTON = (140, 140, 220)
SHOWNBUTTONCLICKED = (170, 170, 255)
NOTSHOWNBUTTON = (220, 140, 140)
NOTSHOWNBUTTONCLICKED = (255, 170, 170)

englishwords = set()
with open("wordlist.txt", 'r') as f:
    lines = f.readlines()
    for line in lines:
        englishwords.add(line[:-1])

# TYPING GLOBALS
WRITTEN = (50, 200, 50)
CORRECTLETTER = (0, 255, 0)
WRONGLETTER = (200, 50, 50)
LETTER = (70, 70, 70)

texts = set()
with open("texts.txt", 'r') as f:
    lines = f.readlines()
    for line in lines:
        if line != "":
            texts.add(line[:-1])



class Reaction:
    

    def __init__(self):
        self.screen = pg.display.set_mode((700, 700))
        self.screen.fill(BACKGROUND)
        self.state = "Idle" # Idle, Wait, Click
        self.timelist = [] # List of reaction times
        self.start = time.time()

    def render(self):
        if self.state == "Idle":
            self.screen.fill(BACKGROUND)
            spacestart = FONT.render("Press Space to Start", 1, TEXT)
            self.screen.blit(spacestart, (10, 50))
            if len(self.timelist) > 0:
                average = FONT.render("Tries: %d" %len(self.timelist), 1, TEXT)
                count = FONT.render("Average: %d ms" %int(np.mean(self.timelist)), 1, TEXT)
                last = FONT.render("%d ms" %self.timelist[-1], 1, TEXT)
                self.screen.blit(last, (200, 250))
                self.screen.blit(average, (200, 350))
                self.screen.blit(count, (200, 400))
        elif self.state == "Wait":
            self.screen.fill(WAIT)
            wait = FONT.render("Wait...", 1, TEXT)
            self.screen.blit(wait, (50, 50))
        elif self.state == "Click":
            self.screen.fill(CLICK)
            click = FONT.render("Click!", 1, TEXT)
            self.screen.blit(click, (50, 50))
        pg.display.update()

    def run(self):
        i = 0
        rand = (random.random()*4 + 2)*100
        while True:
            for event in pg.event.get():
                if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                    main()
                if event.type == pg.KEYDOWN:
                    if event.key == pg.K_SPACE:
                        if self.state == "Idle":
                            self.state = "Wait"
                            self.render()
                if event.type == pg.MOUSEBUTTONDOWN:
                    if self.state == "Click":
                        self.timelist.append(abs(int((time.time() - self.start)*1000) - 35)) #-35 ms to approximately account for the delay caused by the program itself
                        self.state = "Idle"
                        i = 0
                        rand = (random.random()*4 + 2)*100
            self.render()
            time.sleep(0.01)
            if self.state == "Wait":
                if i < rand:
                    i += 1
                else:
                    self.state = "Click"
                    self.start = time.time()

class Sequence:

    def __init__(self, mapsize = 3, speed = 0.75, screensize = 700):
        self.screen = pg.display.set_mode((screensize, screensize))
        self.screensize = screensize
        self.score = 0 
        self.mapsize = mapsize # 3x3, can be 2 for 2x2 or 4 for 4x4 etc.
        self.speed = speed # in seconds, how long it takes between shown boxes in the View state
        self.boxes = [] # list of boxes to click on in order for example [0,3,2,2,1,3] each item must be between 0 and mapsize**2 - 1 included
        self.state = "End" #View, Play, End
        self.index = 0 # current box index, self.boxes[self.index] being the current box youre supposed to click on
        self.clickedbox = None # the box you clicked on
        self.shownbox = None # the box currently shown in view state
    
    def boxtopos(self, box):
        return (box % self.mapsize, box // self.mapsize)
        # 0 1 2
        # 3 4 5
        # 6 7 8
        # in 3x3, 3 -> (0, 1)
        # in 2x2, 3 -> (1, 1)
        # in 3x3, 4 -> (1, 1)

    def postobox(self, pos):
        '''inverse of boxtopos'''
        x, y = pos
        return x + y * self.mapsize
        # in any mapsize, (0,0) -> 0
        # in 3x3, (1,1) -> 4
        # in 2x2, (1,1) -> 3
        # in 5x5, (4,4) -> 24
    
    def addbox(self):
        self.boxes.append(random.randint(0, self.mapsize**2 - 1))

    def update(self):
        self.screen.fill(EMPTY)
        for box in range(self.mapsize**2):
            if box == self.clickedbox:
                pg.draw.rect(self.screen, CLICKED, (box % self.mapsize * self.screensize//self.mapsize, box // self.mapsize * self.screensize//self.mapsize, self.screensize//self.mapsize, self.screensize//self.mapsize))
            elif box == self.shownbox:
                pg.draw.rect(self.screen, SHOWN, (box % self.mapsize * self.screensize//self.mapsize, box // self.mapsize * self.screensize//self.mapsize, self.screensize//self.mapsize, self.screensize//self.mapsize))
        pg.display.update()

    def mousepostobox(self, pos):
        x, y = pos
        if x > self.screensize or y > self.screensize:
            return None
        return self.postobox((x // (self.screensize//self.mapsize), y // (self.screensize//self.mapsize)))
    
    def play(self):
        self.update()
        time.sleep(self.speed)
        while self.state != "End":
            self.addbox()
            for box in self.boxes:
                self.shownbox = box
                self.update()
                time.sleep(self.speed*3/4)
                self.shownbox = None
                self.update()
                time.sleep(self.speed/4)
            self.state = "Play"
            start = time.time()
            self.index = 0
            while self.state == "Play":
                for event in pg.event.get():
                    if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                        main()
                    elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1 and time.time() - start > 0.05:
                        if self.mousepostobox(pg.mouse.get_pos()) != None:
                            self.clickedbox = self.mousepostobox(pg.mouse.get_pos())
                            self.update()
                            time.sleep(self.speed/4)
                            if self.boxes[self.index] == self.clickedbox:
                                self.index += 1
                                self.clickedbox = None
                                self.update()
                                if self.index == len(self.boxes):
                                    self.score += 1
                                    time.sleep(self.speed)
                                    self.state = "View"
                            else:
                                self.shownbox = self.boxes[self.index]
                                self.update()
                                time.sleep(self.speed*2)
                                self.shownbox = None
                                self.clickedbox = None
                                self.state = "End"

    def menu(self):
        self.screen.fill(BACKGROUND)
        pressspace = FONT.render("Press space to play", True, TEXT)
        scorecount = FONT.render(f'Score: {self.score}', True, TEXT)
        self.screen.blit(scorecount, (10, 10))
        self.screen.blit(pressspace, (10, 10 + pressspace.get_height()))
        pg.display.update()
        for event in pg.event.get():
            if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                main()
            elif event.type == pg.KEYDOWN and event.key == pg.K_SPACE:
                self.state = "View"
                self.score = 0
                self.boxes = []

    def run(self):
        while True:
            if self.state == "View" or self.state == "Play":
                self.play()
            elif self.state == "End":
                self.menu()

class Visual:
    def __init__(self, speed = 0.5, screensize = 700):
        self.speed = speed
        self.screen = pg.display.set_mode((screensize, screensize))
        self.screensize = screensize
        self.score = 0
        self.state = "End" #View, Play, End
        self.boxes = set() #List of boxes youre supposed to click on
        self.shownboxes = set() #List of boxes that are shown
        self.clickedboxes = set() #List of boxes you clicked on
        self.currentmapsize = 3 # + 1 when (self.score + 1) / self.currentmapsize**2 > 0.45

    def boxtopos(self, box):
        return (box % self.currentmapsize, box // self.currentmapsize)
    
    def postobox(self, pos):
        x, y = pos
        return x + y * self.currentmapsize
    
    def generate_boxlist(self):
        self.boxes = set()
        while len(self.boxes) < self.score + 1:
            self.boxes.add(random.randint(0, self.currentmapsize**2 - 1))
        
    def update(self):
        self.screen.fill(EMPTY)
        for box in range(self.currentmapsize**2):
            if box in self.shownboxes:
                if box in self.clickedboxes:
                    pg.draw.rect(self.screen, SHLICKED, (box % self.currentmapsize * self.screensize//self.currentmapsize, box // self.currentmapsize * self.screensize//self.currentmapsize, self.screensize//self.currentmapsize, self.screensize//self.currentmapsize))
                else:
                    pg.draw.rect(self.screen, SHOWN, (box % self.currentmapsize * self.screensize//self.currentmapsize, box // self.currentmapsize * self.screensize//self.currentmapsize, self.screensize//self.currentmapsize, self.screensize//self.currentmapsize))
            elif box in self.clickedboxes:
                pg.draw.rect(self.screen, CLICKED, (box % self.currentmapsize * self.screensize//self.currentmapsize, box // self.currentmapsize * self.screensize//self.currentmapsize, self.screensize//self.currentmapsize, self.screensize//self.currentmapsize))
        pg.display.update()

    def mousepostobox(self, pos):
        x, y = pos
        if x > self.screensize or x < 0 or y < 0 or y > self.screensize:
            return None
        return self.postobox((x // (self.screensize//self.currentmapsize), y // (self.screensize//self.currentmapsize)))

    def play(self):
        self.score = 0
        while self.state != "End":
            self.shownboxes = set()
            self.clickedboxes = set()
            self.update()
            time.sleep(self.speed/2)
            self.generate_boxlist()
            self.update()
            time.sleep(self.speed/2)
            self.shownboxes = self.boxes.copy()
            self.update()
            self.state = "Play"
            time.sleep(self.speed)
            start = time.time()
            self.shownboxes = set()
            self.update()
            while self.state == "Play":
                for event in pg.event.get():
                    if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                        main()
                    elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1 and time.time() - start > 0.05:
                        lastclick = self.mousepostobox(pg.mouse.get_pos())
                        if lastclick != None:
                            self.clickedboxes.add(lastclick)
                            self.update()
                            if lastclick in self.boxes:
                                if len(self.clickedboxes) == len(self.boxes):
                                    self.score += 1
                                    if self.score >= self.currentmapsize**2*0.45:
                                        self.currentmapsize += 1
                                    self.state = "View"
                                    time.sleep(self.speed/2)
                                    self.clickedboxes = set()
                                    self.update()
                                    time.sleep(self.speed/2)
                            else:
                                self.shownboxes = self.boxes.copy()
                                self.update()
                                time.sleep(self.speed*2)
                                self.state = "End"
                                self.currentmapsize = 3
                    pg.event.clear(pg.MOUSEBUTTONDOWN)

    def menu(self):
        self.screen.fill(BACKGROUND)
        pressspace = FONT.render("Press space to play", True, TEXT)
        scorecount = FONT.render(f'Score: {self.score}', True, TEXT)
        self.screen.blit(scorecount, (10, 10))
        self.screen.blit(pressspace, (10, 10 + pressspace.get_height()))
        pg.display.update()
        for event in pg.event.get():
            if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                main()
            elif event.type == pg.KEYDOWN and event.key == pg.K_SPACE:
                self.state = "View"

    def run(self):
        while True:
            if self.state == "View" or self.state == "Play":
                self.play()
            elif self.state == "End":
                self.menu()
                
class Chimp:
    def __init__(self, size = 50, screensize = 700):
        self.size = size
        self.screen = pg.display.set_mode((screensize, screensize))
        self.screensize = screensize
        self.score = 3 #3 is the starting point
        self.state = "End" #View, Play, End
        self.boxes = dict() #List of boxes youre supposed to click on (int boxnumber: (int, int) position)
        self.shownboxes = {0,1,2} #List of boxes that are shown without numbers on them, remove one when it is clicked (boxnumber)

    def overlapcheck(self, poslist):
        for pos in poslist:
            for pos2 in poslist:
                if pos != pos2:
                    if (pos[0] <= pos2[0] + self.size*2 and pos[0] >= pos2[0] - self.size*2) and (pos[1] <= pos2[1] + self.size*2 and pos[1] >= pos2[1] - self.size*2):
                        return True
        return False

    def generate_boxdict(self):
        self.boxes = dict()
        poslist = [(random.randint(self.size, self.screensize-self.size), random.randint(self.size, self.screensize-self.size)) for i in range(self.score)]
        while self.overlapcheck(poslist):
            poslist = [(random.randint(self.size, self.screensize-self.size), random.randint(self.size, self.screensize-self.size)) for i in range(self.score)]
        for i in range(self.score):
            self.boxes[i] = poslist[i]
        self.shownboxes = {j for j in range(self.score)}
        
    def update(self):
        self.screen.fill(EMPTY)
        if self.state == "View":
            for box in self.boxes:
                pg.draw.rect(self.screen, SHOWN, (self.boxes[box][0]-self.size, self.boxes[box][1]-self.size, self.size*2, self.size*2))
                text = FONT.render(str(box + 1), True, TEXT)
                self.screen.blit(text, (self.boxes[box][0]-text.get_width()//2, self.boxes[box][1]-text.get_height()//2))
        elif self.state == "Play":
            for box in self.shownboxes:
                pg.draw.rect(self.screen, SHOWN, (self.boxes[box][0]-self.size, self.boxes[box][1]-self.size, self.size*2, self.size*2))
        pg.display.update()

    def mousepostobox(self, pos):
        x, y = pos
        if x > self.screensize or x < 0 or y < 0 or y > self.screensize:
            return None
        for box in self.boxes:
            if self.boxes[box][0]-self.size <= x and x <= self.boxes[box][0]+self.size and self.boxes[box][1]-self.size <= y and y <= self.boxes[box][1]+self.size:
                return box
        return None

    def play(self):
        self.score = 3
        self.shownboxes = {0,1,2}
        while self.state != "End":
            self.boxes = dict()
            self.update()
            time.sleep(0.1)
            self.generate_boxdict()
            self.update()
            self.state = "Play"
            while self.state == "Play":
                for event in pg.event.get():
                    if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                        main()
                    elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
                        lastclick = self.mousepostobox(pg.mouse.get_pos())
                        if lastclick != None and lastclick in self.shownboxes:
                            if lastclick == len(self.boxes) - len(self.shownboxes):
                                self.shownboxes.remove(len(self.boxes) - len(self.shownboxes))
                                self.update()
                                if len(self.shownboxes) == 0:
                                    self.score += 1
                                    self.update()
                                    self.state = "View"
                            else:
                                self.state = "End"
                    pg.event.clear(pg.MOUSEBUTTONDOWN)

    def menu(self):
        self.screen.fill(BACKGROUND)
        pressspace = FONT.render("Press space to play", True, TEXT)
        if self.score > 3:
            scorecount = FONT.render(f'Score: {self.score - 1}', True, TEXT)
            self.screen.blit(scorecount, (10, 10))
        self.screen.blit(pressspace, (10, 10 + pressspace.get_height()))
        pg.display.update()
        for event in pg.event.get():
            if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                main()
            elif event.type == pg.KEYDOWN and event.key == pg.K_SPACE:
                self.state = "View"

    def run(self):
        while True:
            if self.state == "View" or self.state == "Play":
                self.play()
            elif self.state == "End":
                self.menu()
                
class Aim:

    def __init__(self, size = 50, screenheight = 700, screenwidth = 1000, boxcount = 20):
        self.screen = pg.display.set_mode((screenwidth, screenheight))
        self.screenheight = screenheight
        self.screenwidth = screenwidth
        self.boxcount = boxcount
        self.box = None # position of the current box, ex: (230, 473), becomes None when the game is over
        self.size = size # in pixels, how big the boxes are
        self.times = [] # list of milliseconds between hits
        self.lastclick = 0
        self.state = "End" #Play, End
    
    def placebox(self):
        self.box = (random.randint(self.size, self.screenwidth - self.size), random.randint(self.size, self.screenheight - self.size))

    def update(self):
        self.screen.fill(EMPTY)
        if self.box:
            pg.draw.rect(self.screen, SHOWN, (self.box[0], self.box[1], self.size, self.size))
        pg.display.update()

    def isinbox(self, pos):
        x, y = pos
        if x > self.box[0] and x < self.box[0] + self.size and y > self.box[1] and y < self.box[1] + self.size:
            return True
        return False
    
    def play(self):
        self.update()
        time.sleep(0.5)
        while self.state != "End":
            self.placebox()
            self.update()
            self.lastclick = time.time()
            while self.box:
                for event in pg.event.get():
                    if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                        main()
                    elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
                        if self.isinbox(pg.mouse.get_pos()):
                            self.box = None
                            self.times.append(time.time() - self.lastclick)
                            self.lastclick = self.times[-1]
                            self.update()
                            if len(self.times) == self.boxcount:
                                time.sleep(0.5)
                                self.state = "End"

    def menu(self):
        self.screen.fill(BACKGROUND)
        pressspace = FONT.render("Press space to play", True, TEXT)
        if len(self.times):
            scorecount = FONT.render(f'Average time between hits: {int(round(np.mean(self.times), 4)*1000)} ms', True, TEXT)
            self.screen.blit(scorecount, (10, 10))
        self.screen.blit(pressspace, (10, 10 + pressspace.get_height()))
        pg.display.update()
        for event in pg.event.get():
            if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                main()
            elif event.type == pg.KEYDOWN and event.key == pg.K_SPACE:
                self.state = "Play"
                self.box = None
                self.times = []

    def run(self):
        while True:
            if self.state == "Play":
                self.play()
            elif self.state == "End":
                self.menu()

class Numbers:
    def __init__(self, screenwidth = 1000, screenheight = 700):
        self.screen = pg.display.set_mode((screenwidth, screenheight))
        self.height = screenheight
        self.width = screenwidth
        self.score = 0
        self.state = "End" #View, Play, Correct, End
        self.number = None #Number to repeat
        self.input = None #Inputted number
    
    def generate_number(self):
        self.number = random.randint(10**self.score, 10**(self.score+1)-1)
        
    def update(self):
        self.screen.fill(EMPTY)
        if self.state == "View":
            text = FONT.render(f"{self.number}", True, TEXT)
            text_rect = text.get_rect(center=(self.width/2, self.height/2))
            self.screen.blit(text, text_rect)
        elif self.state == "Play" and self.input != None:
            text = FONT.render(f"{self.input}", True, TEXT)
            text_rect = text.get_rect(center=(self.width/2, self.height/2))
            self.screen.blit(text, text_rect)
        elif self.state == "Correct":
            if self.input == self.number:
                text1 = FONT.render(f"{self.number}", True, WIN)
                text2 = FONT.render(f"{self.input}", True, WIN)
            else:
                text1 = FONT.render(f"{self.number}", True, LOSS)
                text2 = FONT.render(f"{self.input}", True, LOSS)
            text_rect1 = text1.get_rect(center=(self.width/2, self.height/2 - text1.get_height()))
            text_rect2 = text2.get_rect(center=(self.width/2, self.height/2 + text2.get_height()))
            self.screen.blit(text1, text_rect1)
            self.screen.blit(text2, text_rect2)
        pg.display.update()

    def countdown(self, count, color):
        pg.draw.rect(self.screen, color, (0,0,self.width, self.height//10))
        pg.display.update()
        for i in range(self.width):
            time.sleep(round(count/self.width, 3))
            pg.draw.rect(self.screen, EMPTY, (self.width - i, 0, self.width, self.height//10))
            pg.display.update()

    def play(self):
        self.score = 0
        self.input = None
        while self.state != "End":
            self.input = None
            self.generate_number()
            self.update()
            self.countdown(self.score + 1, WIN)
            start = time.time()
            self.state = "Play"
            self.input = None
            self.update()
            while self.state == "Play":
                for event in pg.event.get():
                    if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                        main()
                    elif event.type == pg.KEYDOWN and event.key in {pg.K_0, pg.K_1, pg.K_2, pg.K_3, pg.K_4, pg.K_5, pg.K_6, pg.K_7, pg.K_8, pg.K_9, pg.K_BACKSPACE}:
                        if not self.input and event.key != pg.K_BACKSPACE and time.time() - start > 0.05:
                            self.input = event.key - pg.K_0
                            self.update()
                        elif event.key == pg.K_BACKSPACE:
                            self.input //= 10
                            self.update()
                        elif self.input: 
                            self.input = self.input*10 + event.key - pg.K_0
                            self.update()
                    elif event.type == pg.KEYDOWN and event.key == pg.K_RETURN and self.input and self.state == "Play":
                        self.state = "Correct"
                        self.update()
                        self.countdown(1.5, SHOWN)
                        if self.input == self.number:
                            self.score += 1
                            self.state = "View"
                        else:
                            self.state = "End"
                    pg.event.clear(pg.KEYDOWN)

    def menu(self):
        self.screen.fill(BACKGROUND)
        pressspace = FONT.render("Press space to play", True, TEXT)
        if self.score > 1:
            scorecount = FONT.render(f'Score: {self.score}', True, TEXT)
            self.screen.blit(scorecount, (10, 10))
        self.screen.blit(pressspace, (10, 10 + pressspace.get_height()))
        pg.display.update()
        for event in pg.event.get():
            if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                main()
            elif event.type == pg.KEYDOWN and event.key == pg.K_SPACE:
                self.state = "View"

    def run(self):
        while True:
            if self.state == "View" or self.state == "Play":
                self.play()
            elif self.state == "End":
                self.menu()
   
class Verbal:
    def __init__(self, screensize = 700, buttonsize = 100):
        self.screen = pg.display.set_mode((screensize, screensize))
        self.screensize = screensize
        self.buttonsize = buttonsize
        self.score = 0
        self.state = "End" #End, Play
        self.words = set()
        self.shownwords = set()
        self.currentword = None #Word to check, string
        self.clicked = None #"shown", "notshown", None
    
    def initialize_wordset(self):
        self.words = englishwords

    def random_word(self):
        if self.currentword:
            self.shownwords.add(self.currentword)
        # 0.7 chance of a new word from self.words, 0.3 chance of a word from self.shownwords
        if random.random() < 0.7 or len(self.shownwords) < 4:
            self.currentword = random.choice(list(self.words))
        elif len(self.shownwords) > 3:
            self.currentword = random.choice(list(self.shownwords))
    
    def check(self): #True or False
        if self.currentword in self.shownwords:
            return self.clicked == "shown"
        else:
            return self.clicked == "notshown"

    def mousepostobox(self, pos):
        x, y = pos
        if not (x > self.screensize or x < 0 or y < 0 or y > self.screensize) and y >= self.screensize - self.buttonsize and y < self.screensize:
            if x < self.screensize / 2:
                self.clicked = "shown"
            else:
                self.clicked = "notshown"
        else:
            self.clicked = None

    def update(self):
        self.screen.fill(EMPTY)
        currentword_text = FONT.render(f"{self.currentword}", True, TEXT)
        currentword_rect = currentword_text.get_rect(center=(self.screensize//2, self.screensize/2 - currentword_text.get_height()))
        self.screen.blit(currentword_text, currentword_rect)


        pg.draw.rect(self.screen, SHOWNBUTTON, (0, self.screensize - self.buttonsize, self.screensize/2, self.buttonsize))
        pg.draw.rect(self.screen, NOTSHOWNBUTTON, (self.screensize/2, self.screensize - self.buttonsize, self.screensize/2, self.buttonsize))

        if self.clicked == "shown":
            pg.draw.rect(self.screen, SHOWNBUTTONCLICKED, (0, self.screensize - self.buttonsize, self.screensize/2, self.buttonsize))
        elif self.clicked == "notshown":
            pg.draw.rect(self.screen, NOTSHOWNBUTTONCLICKED, (self.screensize/2, self.screensize - self.buttonsize, self.screensize/2, self.buttonsize))
        
        shownbutton_text = FONT.render("Seen", True, TEXT)
        shownbutton_rect = shownbutton_text.get_rect(center=(self.screensize//4, self.screensize - self.buttonsize//2))
        self.screen.blit(shownbutton_text, shownbutton_rect)

        notshownbutton_text = FONT.render("New", True, TEXT)
        notshownbutton_rect = notshownbutton_text.get_rect(center=(3*self.screensize//4, self.screensize - self.buttonsize//2))
        self.screen.blit(notshownbutton_text, notshownbutton_rect)

        pg.display.update()


    def play(self):
        self.shownwords = set()
        while self.state == "Play":
            self.random_word()
            self.update()
            self.clicked = None
            self.update()
            while not self.clicked:
                for event in pg.event.get():
                    if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                        main()
                    elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
                        self.mousepostobox(event.pos)
                        if self.clicked:
                            self.update()
                            if self.check():
                                self.score += 1
                                time.sleep(0.1)
                            else:
                                self.state = "End"
                                time.sleep(0.2)

    def menu(self):
        self.screen.fill(BACKGROUND)
        pressspace = FONT.render("Press space to play", True, TEXT)
        if self.score > 1:
            scorecount = FONT.render(f'Score: {self.score}', True, TEXT)
            self.screen.blit(scorecount, (10, 10))
        self.screen.blit(pressspace, (10, 10 + pressspace.get_height()))
        pg.display.update()
        for event in pg.event.get():
            if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                main()
            elif event.type == pg.KEYDOWN and event.key == pg.K_SPACE:
                self.state = "Play"

    def run(self):
        self.initialize_wordset()
        while True:
            if self.state == "Play":
                self.score = 0
                self.play()
            elif self.state == "End":
                self.menu()

class Typing:
    def __init__(self, screenwidth = 1000, screenheight = 700): 
        self.screen = pg.display.set_mode((screenwidth, screenheight))
        self.screenwidth = screenwidth
        self.screenheight = screenheight
        self.starttime = 0 #time.time() when first character is typed
        self.text = "" #Text to type
        self.written = "" #typed part of self.text
        self.timer = 0 #time.time() - self.starttime
        self.wpm = 0 #WPM formula
        self.mistakecount = 0 #mistakes made
        self.accuracy = "100.00%" #Accuracy formula
        self.start = False
        self.maxwritten = 0
        self.state = "End" #"Play" or "End"

    def update_timer(self):
        if self.starttime != 0:
            self.timer = int(time.time() - self.starttime)
        if self.timer != 0:
            self.wpm = int((len(self.written) / 5) / (self.timer / 60))
        if len(self.written) != 0:
            self.accuracy = str(round(100 - (self.mistakecount / self.maxwritten) * 100, 2)) + '%'

    def random_text(self):
        self.text = random.choice(list(texts))
        self.written = ""
    
    def drawText(self, surface, text, color, rect, font, aa=False, bkg=None):
        rect = pg.Rect(rect)
        y = rect.top
        lineSpacing = -2

        # get the height of the font
        fontHeight = font.size("Tg")[1]

        while text:
            i = 1

            # determine if the row of text will be outside our area
            if y + fontHeight > rect.bottom:
                break

            # determine maximum width of line
            while font.size(text[:i])[0] < rect.width and i < len(text):
                i += 1

            # if we've wrapped the text, then adjust the wrap to the last word      
            if i < len(text): 
                i = text.rfind(" ", 0, i) + 1

            # render the line and blit it to the surface
            if bkg:
                image = font.render(text[:i], 1, color, bkg)
                image.set_colorkey(bkg)
            else:
                image = font.render(text[:i], aa, color)

            surface.blit(image, (rect.left, y))
            y += fontHeight + lineSpacing

            # remove the text we just blitted
            text = text[i:]

        return text

    def update(self):
        self.screen.fill(EMPTY)
        WPM_text = FONT.render(f"WPM: {self.wpm}", True, TEXT)
        ACCURACY_text = FONT.render(f"Accuracy: {self.accuracy}", True, TEXT)
        TIMER_text = FONT.render(f"{self.timer}", True, TEXT)
        self.screen.blit(WPM_text, (0, 0))
        self.screen.blit(TIMER_text, (self.screenwidth - TIMER_text.get_width(), 0))
        self.screen.blit(ACCURACY_text, ((self.screenwidth - ACCURACY_text.get_width())//2, 0))

        self.drawText(self.screen, self.text, LETTER, (0,WPM_text.get_height()*2, self.screenwidth, self.screenheight), FONT)
        self.drawText(self.screen, self.written, WRITTEN, (0,WPM_text.get_height()*2, self.screenwidth, self.screenheight), FONT)

        if len(self.written) > 0 and len(self.text) != len(self.written):
            lastchar = ""
            for i in self.written[:-1]:
                lastchar += i
            if self.written == self.text[:len(self.written)]:
                self.drawText(self.screen, lastchar, CORRECTLETTER, (0,WPM_text.get_height()*2, self.screenwidth, self.screenheight), FONT)
            else:
                lastchar += self.written[-1]
                self.drawText(self.screen, lastchar, WRONGLETTER, (0,WPM_text.get_height()*2, self.screenwidth, self.screenheight), FONT)

        pg.display.update()
    
    def menu(self):
        self.screen.fill(BACKGROUND)
        pressspace = FONT.render("Press space to play", True, TEXT)
        if self.wpm > 0:
            scorecount = FONT.render(f'WPM: {self.wpm}', True, TEXT)
            accuracy = FONT.render(f'Accuracy: {self.accuracy}', True, TEXT)
            self.screen.blit(scorecount, (10, 10))
            self.screen.blit(accuracy, (10, 10 + scorecount.get_height()))
        self.screen.blit(pressspace, (10, 10 + pressspace.get_height() * 2))
        pg.display.update()
        for event in pg.event.get():
            if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                main()
            elif event.type == pg.KEYDOWN and event.key == pg.K_SPACE:
                self.start = False
                self.state = "Play"

    def resetvars(self):
        self.starttime = 0
        self.accuracy = "100.00%"
        self.mistakecount = 0
        self.maxwritten = 0
        self.start = False

    def play(self):
        self.resetvars()
        self.random_text()
        while self.state == "Play":
            for event in pg.event.get():
                if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                    self.state = "End"
                elif event.type == pg.KEYDOWN:
                    if not self.starttime and not self.start:
                        self.starttime = time.time()
                        self.start = True
                    if event.key == pg.K_BACKSPACE:
                        self.written = self.written[:-1]
                    elif event.key == pg.K_SPACE:
                        if len(self.written) < 3 or self.written[:len(self.written) - 2] == self.text[:len(self.written) - 2]:
                            if event.unicode != '' and event.unicode != self.text[len(self.written)]:
                                self.mistakecount += 1
                        self.written += " "
                    elif len(self.written) < 3 or self.written[:len(self.written) - 2] == self.text[:len(self.written) - 2]:
                        if event.unicode != '' and event.unicode != self.text[len(self.written)]:
                            self.mistakecount += 1
                        self.written += event.unicode
            if len(self.written) > self.maxwritten:
                self.maxwritten = len(self.written)
            self.update_timer()
            self.update()
            if len(self.written) == len(self.text):
                self.state = "End"

    def run(self):
        while True:
            if self.state == "Play":
                self.play()
            elif self.state == "End":
                self.menu()

class ALL:
    def __init__(self, screensize):
        self.screen = pg.display.set_mode((screensize, screensize))
        self.screensize = screensize

        self.reaction = pg.image.load("Reaction.png")
        self.reaction = pg.transform.scale(self.reaction, (self.screensize//3, self.screensize//3))

        self.sequence = pg.image.load("Sequence.png")
        self.sequence = pg.transform.scale(self.sequence, (self.screensize//3, self.screensize//3))

        self.visual = pg.image.load("Visual.png")
        self.visual = pg.transform.scale(self.visual, (self.screensize//3, self.screensize//3))

        self.chimp = pg.image.load("Chimp.png")
        self.chimp = pg.transform.scale(self.chimp, (self.screensize//3, self.screensize//3))

        self.aim = pg.image.load("Aim.png")
        self.aim = pg.transform.scale(self.aim, (self.screensize//3, self.screensize//3))

        self.numbers = pg.image.load("Numbers.png")
        self.numbers = pg.transform.scale(self.numbers, (self.screensize//3, self.screensize//3))

        self.verbal = pg.image.load("Verbal.png")
        self.verbal = pg.transform.scale(self.verbal, (self.screensize//3, self.screensize//3))

        self.typing = pg.image.load("Typing.png")
        self.typing = pg.transform.scale(self.typing, (self.screensize//3, self.screensize//3))

        self.menu = pg.image.load("Menu.png")
        self.menu = pg.transform.scale(self.menu, (self.screensize//3, self.screensize//3))

    def drawText(self, surface, text, color, rect, font, aa=False, bkg=None):
        rect = pg.Rect(rect)
        y = rect.top
        lineSpacing = -2

        # get the height of the font
        fontHeight = font.size("Tg")[1]

        while text:
            i = 1

            # determine if the row of text will be outside our area
            if y + fontHeight > rect.bottom:
                break

            # determine maximum width of line
            while font.size(text[:i])[0] < rect.width and i < len(text):
                i += 1

            # if we've wrapped the text, then adjust the wrap to the last word      
            if i < len(text): 
                i = text.rfind(" ", 0, i) + 1

            # render the line and blit it to the surface
            if bkg:
                image = font.render(text[:i], 1, color, bkg)
                image.set_colorkey(bkg)
            else:
                image = font.render(text[:i], aa, color)

            surface.blit(image, (rect.left, y))
            y += fontHeight + lineSpacing

            # remove the text we just blitted
            text = text[i:]

        return text

    def update(self):
        self.screen.fill(BACKGROUND)

        self.screen.blit(self.reaction, (0,0))
        self.screen.blit(self.sequence, (0,self.screensize//3))
        self.screen.blit(self.visual, (0,self.screensize//3*2))
        self.screen.blit(self.chimp, (self.screensize//3,0))
        self.screen.blit(self.menu, (self.screensize//3, self.screensize // 3))
        self.screen.blit(self.aim, (self.screensize//3,self.screensize//3*2))
        self.screen.blit(self.numbers, (self.screensize//3*2,0))
        self.screen.blit(self.verbal, (self.screensize//3*2,self.screensize//3))
        self.screen.blit(self.typing, (self.screensize//3*2,self.screensize//3*2))

        pg.display.update()

    def run(self):
        self.update()
        game = None
        while not game:
            for event in pg.event.get():
                self.update()
                if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                    pg.quit()
                    sys.exit()
                elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
                    if event.pos[0] < self.screensize/3:
                        if event.pos[1] < self.screensize/3:
                            game = Reaction()
                        elif event.pos[1] < self.screensize*2/3:
                            game = Sequence(MAPSIZE, SEQSPEED, SCREENSIZE)
                        else:
                            game = Visual(VISSPEED, SCREENSIZE)
                    elif event.pos[0] < self.screensize*2/3:
                        if event.pos[1] < self.screensize/3:
                            game = Chimp(CHIMPSIZE, SCREENSIZE)
                        elif event.pos[1] > self.screensize*2/3:
                            game = Aim(AIMSIZE, HEIGHT, WIDTH, BOXCOUNT)
                    else:
                        if event.pos[1] < self.screensize/3:
                            game = Numbers(WIDTH, HEIGHT)
                        elif event.pos[1] < self.screensize*2/3:
                            game = Verbal(SCREENSIZE, BUTTONSIZE)
                        else:
                            game = Typing(WIDTH, HEIGHT)
                    if game:
                        game.run()

def main():
    all = ALL(750)
    all.run()

if __name__ == "__main__":
    main()